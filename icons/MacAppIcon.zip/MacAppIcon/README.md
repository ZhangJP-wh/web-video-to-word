# macOS App 图标资源

- `AppIcon.icns`：macOS 应用图标文件。
- `AppIcon.appiconset`：拖入 Xcode 的 Assets.xcassets，用作 AppIcon。
- `AppIcon.iconset`：包含标准 1x / 2x PNG，可用 iconutil 重建 ICNS。
- `AppIcon-1024.png`：1024 × 1024 透明 PNG。
- `AppIcon-original-1254.png`：原始尺寸的透明母版。

仅处理外部白色底色，保留内部图案、白色分隔线和外部柔和阴影；未裁切、未增强、未重新绘制。小尺寸图标使用 Lanczos 等比例缩小。
透明母版的内部图案 RGB 像素与原图相同。外部白底与阴影使用透明度分离；近白色背景噪点（各通道至少 247）清除为透明，其余位置叠回白底后通道误差不超过 1/255（8 位取整）。原始白底图片无法唯一恢复原生透明阴影，透明阴影为保持原白底观感的数学分离结果。
